# MundoIA Android — versión 0.4 alpha

**Qué es:** una aplicación Android acompañante para crear paquetes de poderes de Minecraft Bedrock a partir de descripciones libres. No aloja mundos ni busca servidores.

## Qué hace esta primera base

- Pantalla Android nativa en español.
- Importación de referencia `.mcworld`, `.mcaddon`, `.mcpack` o `.zip` con inspección limitada de manifiestos y archivos de texto de Behavior/Resource Packs; omite bases de datos y datos del jugador.
- Campos para configurar un proveedor HTTPS compatible con la API `Chat Completions`, un modelo y una clave API opcional/según el proveedor.
- La clave API se mantiene solo en memoria mientras la app está abierta; no se guarda en preferencias.
- Envía la descripción a la IA y solicita código JavaScript para `@minecraft/server` y archivos JSON de Behavior/Resource Pack.
- Valida rutas, limita el tamaño de respuesta y bloquea algunos patrones peligrosos de código generado.
- Guarda una biblioteca local de hasta 30 poderes y exporta un solo `.mcaddon` actualizado con un Behavior Pack + Resource Pack y un objeto de activación por poder. Los UUID se conservan entre exportaciones para identificar la misma biblioteca. Si generas de nuevo un poder con el mismo nombre, se actualiza su entrada en vez de duplicarlo.
- Verifica que el ZIP y los manifiestos esenciales se puedan leer antes de ofrecer el archivo.
- Usa una llamada HTTPS directa desde el teléfono al proveedor de IA. No requiere un servidor de Minecraft ni un servidor propio de MundoIA.

## Lo que NO hace todavía

- No es un APK compilado. Es el proyecto fuente Android.
- No se ha podido compilar ni probar en un teléfono real desde este entorno porque aquí no hay Android SDK ni Gradle instalados.
- No detecta ni se conecta a una partida local de Minecraft que ya esté abierta.
- No puede modificar los archivos privados de Minecraft mientras el mundo está abierto.
- No activa automáticamente el addon en un mundo. Después de guardar el `.mcaddon`, hay que abrirlo con Minecraft e incluir sus Behavior/Resource Packs en la configuración del mundo.
- El generador de esta alpha produce código y recursos de texto/JSON. No genera todavía archivos PNG/modelos de textura mediante un servicio de imágenes; el paquete usa una pluma base incluida.
- No garantiza que cualquier código generado vaya a funcionar en todas las versiones de Bedrock. Hay que probar el addon en una copia del mundo.

## Requisitos para usar la generación por IA

1. Un proveedor de IA que acepte el formato `POST /v1/chat/completions` (o su equivalente compatible).
2. La dirección HTTPS base del proveedor.
3. El nombre exacto del modelo.
4. Una clave API, si el proveedor la exige.

**Importante:** algunos proveedores cobran por uso. No introduzcas una clave ni actives un servicio de pago sin permiso de la persona adulta responsable. No compartas la clave con nadie. MundoIA no almacena la clave. Cuando generas un poder, el proveedor recibe la descripción y, si importaste una referencia, los manifiestos y archivos de texto permitidos que se extrajeron de ella. No se envían las bases de datos del mundo ni datos del jugador.

La app inspecciona los archivos ZIP de referencia de forma limitada: permite manifiestos y texto de las carpetas de packs; omite `db/`, `playerdata/`, logs, capturas y binarios. El contexto permitido se incorpora al mensaje enviado al proveedor de IA al tocar Generar.

## Versión de Script API

El valor inicial es `2.10.0`, la versión estable de `@minecraft/server` que Microsoft indica para Bedrock 1.26.50. La rama 2.x es una versión mayor distinta de 1.x, así que no se debe mezclar código diseñado para ambas. El paquete fija Minecraft 1.26.50 como versión mínima; si tu juego es anterior, este paquete no es compatible. Verifica la versión de tu Bedrock antes de usar el addon.

## Abrir el proyecto

Abre la carpeta `MundoIA-Android-0.4` en Android Studio y deja que Gradle sincronice los plugins. El proyecto apunta a Android SDK 35, mínimo Android 8.0 (API 26). Después puedes compilar una APK de depuración desde Android Studio.

Este entorno no incluye Android SDK ni Gradle, por lo que no se proporciona una APK falsa o no probada. El proyecto fuente sí incluye instrucciones para abrirlo y compilarlo desde Android Studio.

## Estructura

- `app/src/main/java/com/mundoia/app/MainActivity.kt` — interfaz y selección/guardado de archivos.
- `AiPackGenerator.kt` — conexión con el proveedor de IA y validación de la respuesta.
- `ReferenceArchiveReader.kt` — extracción segura y limitada del contexto textual de packs, sin leer la base de datos del mundo.
- `PowerProjectStore.kt` — biblioteca local persistente y UUID estables del proyecto.
- `PowerPackBuilder.kt` — creación y verificación del `.mcaddon` unificado.
- `app/src/main/assets/power_icon.png` — icono base de la pluma.

## Próxima fase

La prioridad pendiente es investigar una integración autorizada para Android + Bedrock que pueda comunicarse con una partida local sin alojarla en otro servidor. No se ha implementado ni simulado esa conexión en esta alpha. Android restringe el acceso de otras apps a `Android/data/com.mojang.minecraftpe`, incluso para apps con acceso amplio al almacenamiento; consulta la documentación oficial de Android y Mojang antes de prometer edición directa.
