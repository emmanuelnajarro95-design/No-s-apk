# Cómo obtener el APK desde un teléfono Android

Este proyecto todavía es código fuente. Este flujo usa GitHub Actions para compilarlo en la nube; no instala Minecraft ni aloja tu mundo.

## Pasos
1. Inicia sesión en GitHub desde el navegador del teléfono y crea un repositorio nuevo llamado `MundoIA-Android`. Para esta prueba puedes elegirlo privado.
2. Sube **el contenido** de esta carpeta al repositorio (no subas la carpeta contenedora `MundoIA-Android-0.4` como una carpeta extra).
3. En el repositorio, abre la pestaña **Actions** y habilita los workflows si GitHub lo solicita.
4. Selecciona **Build MundoIA APK** y pulsa **Run workflow**.
5. Espera a que termine la ejecución. Si falla, abre el registro y comparte el error; no asumas que ya existe un APK.
6. Si termina en verde, abre la ejecución y descarga el artefacto **MundoIA-debug-apk**. Dentro está `app-debug.apk`.
7. Descarga el APK en Android y, si decides instalarlo, revisa los permisos que solicita. Es una compilación de depuración, no una versión publicada.

## Notas
- GitHub compilará el código en una máquina temporal; no es un servidor de Minecraft.
- No pongas claves API en el repositorio. La clave de IA debe introducirse solo en la app y únicamente en un proveedor de confianza.
- Este flujo compila; no demuestra que la integración con una partida abierta de Minecraft ya funcione.
