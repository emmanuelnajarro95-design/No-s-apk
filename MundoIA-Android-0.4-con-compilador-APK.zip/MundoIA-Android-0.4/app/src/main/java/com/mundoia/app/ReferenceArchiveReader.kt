package com.mundoia.app

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Inspects an imported Minecraft archive without reading world databases or player data.
 * Only manifests and small text files from BP/RP folders are exposed to the AI prompt.
 */
object ReferenceArchiveReader {
    data class Inspection(val summary: String, val promptContext: String)

    private const val MAX_PROMPT_CHARS = 55_000
    private const val MAX_FILE_CHARS = 12_000
    private const val MAX_FILES = 45
    private const val MAX_NESTED_ARCHIVE_BYTES = 20 * 1024 * 1024

    private val allowedExtensions = setOf(
        "json", "js", "mjs", "ts", "lang", "txt", "mcfunction", "molang", "material"
    )
    private val relevantRoots = setOf(
        "behavior_packs", "resource_packs", "development_behavior_packs",
        "development_resource_packs", "scripts", "items", "entities", "blocks",
        "entity", "attachables", "materials", "animations", "animation_controllers", "render_controllers", "particles",
        "texts", "recipes", "loot_tables", "spawn_rules"
    )
    private val excludedSegments = setOf(
        "db", "playerdata", "players", "logs", "screenshots", "cache", "behavior_pack_history"
    )

    fun inspect(file: File): Inspection {
        require(file.isFile && file.length() > 0L) { "El archivo está vacío o no existe." }
        val textFiles = linkedMapOf<String, String>()
        val allNames = linkedSetOf<String>()
        val errors = mutableListOf<String>()

        file.inputStream().use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) {
                        zip.closeEntry()
                        continue
                    }
                    val name = safeArchivePath(entry.name)
                    if (name == null) {
                        zip.closeEntry()
                        continue
                    }
                    allNames += name
                    val lower = name.lowercase()
                    if (lower.endsWith(".mcpack") || lower.endsWith(".zip")) {
                        val nested = readLimited(zip, MAX_NESTED_ARCHIVE_BYTES)
                        if (nested != null) {
                            inspectNested(nested, name, textFiles, allNames)
                        }
                    } else if (isRelevantTextPath(name)) {
                        if (textFiles.size >= MAX_FILES) {
                            errors += "Se alcanzó el límite de archivos inspeccionados."
                            zip.closeEntry()
                            break
                        }
                        val bytes = readLimited(zip, MAX_FILE_CHARS * 4)
                        if (bytes != null) {
                            val content = bytes.toString(Charsets.UTF_8).trim()
                            if (content.isNotBlank() && !content.contains('\u0000')) {
                                textFiles[name] = content.take(MAX_FILE_CHARS)
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
        }

        val manifests = allNames.count { it.substringAfterLast('/').equals("manifest.json", true) }
        val result = buildString {
            append("Entradas ZIP: ${allNames.size}. Manifiestos encontrados: $manifests. Archivos de texto relevantes leídos: ${textFiles.size}.")
            if (errors.isNotEmpty()) append(" ${errors.distinct().joinToString(" ")}")
        }
        val context = buildString {
            append("CONTEXTO DE REFERENCIA IMPORTADO (solo metadatos y archivos de texto allowlisted; no es el mundo completo):\n")
            append("Archivo: ${file.name}\n")
            append("Entradas relevantes: ${allNames.filter { isRelevantTextPath(it) || it.endsWith(".mcpack", true) }.take(100).joinToString(" | ")}\n")
            for ((path, content) in textFiles) {
                if (length >= MAX_PROMPT_CHARS) break
                val block = "\n--- ARCHIVO: $path ---\n$content\n"
                append(block.take(MAX_PROMPT_CHARS - length))
            }
        }.take(MAX_PROMPT_CHARS)

        return Inspection(result, context)
    }

    private fun inspectNested(
        archiveBytes: ByteArray,
        prefix: String,
        output: MutableMap<String, String>,
        allNames: MutableSet<String>
    ) {
        ZipInputStream(ByteArrayInputStream(archiveBytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) {
                    zip.closeEntry()
                    continue
                }
                val child = safeArchivePath(entry.name)
                if (child != null) {
                    val full = "$prefix!/$child"
                    allNames += full
                    if (output.size < MAX_FILES && isRelevantTextPath(child)) {
                        val bytes = readLimited(zip, MAX_FILE_CHARS * 4)
                        if (bytes != null) {
                            val content = bytes.toString(Charsets.UTF_8).trim()
                            if (content.isNotBlank() && !content.contains('\u0000')) {
                                output[full] = content.take(MAX_FILE_CHARS)
                            }
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun isRelevantTextPath(path: String): Boolean {
        val normalized = path.replace('\\', '/')
        val segments = normalized.split('/')
        if (segments.any { it.lowercase() in excludedSegments || it.startsWith(".") }) return false
        val extension = normalized.substringAfterLast('.', "").lowercase()
        if (extension !in allowedExtensions) return false
        val first = segments.firstOrNull()?.lowercase() ?: return false
        val fileName = segments.last().lowercase()
        return fileName == "manifest.json" || first in relevantRoots ||
            fileName == "world_behavior_packs.json" || fileName == "world_resource_packs.json"
    }

    private fun safeArchivePath(path: String): String? {
        val normalized = path.replace('\\', '/').trim()
        if (normalized.isBlank() || normalized.startsWith('/') || normalized.contains(':')) return null
        val segments = normalized.split('/')
        if (segments.any { it.isBlank() || it == "." || it == ".." }) return null
        if (segments.any { it.any(Char::isISOControl) }) return null
        return normalized
    }

    /** Returns null when the entry exceeds the configured byte limit. */
    private fun readLimited(input: java.io.InputStream, maxBytes: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) return null
            out.write(buffer, 0, count)
        }
        return out.toByteArray()
    }
}
