package com.mundoia.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Persistent local project: one BP/RP pair, stable UUIDs, and a collection of powers. */
object PowerProjectStore {
    data class PackIds(
        val behaviorHeader: String,
        val behaviorDataModule: String,
        val behaviorScriptModule: String,
        val resourceHeader: String,
        val resourceModule: String
    )

    data class Snapshot(
        val powers: List<GeneratedPower>,
        val buildNumber: Int,
        val ids: PackIds
    )

    private fun projectFile(filesDir: File) = File(filesDir, "mundoia-project/project.json")

    @Synchronized
    fun addPower(filesDir: File, power: GeneratedPower): Snapshot {
        val old = loadSnapshot(filesDir)
        val id = slug(power.name)
        val powers = old.powers.toMutableList()
        val existing = powers.indexOfFirst { slug(it.name) == id }
        if (existing >= 0) powers[existing] = power else powers.add(power)
        require(powers.size <= 30) { "La biblioteca admite hasta 30 poderes en esta versión." }
        val next = Snapshot(powers, old.buildNumber + 1, old.ids)
        save(filesDir, next)
        return next
    }

    @Synchronized
    fun loadSnapshot(filesDir: File): Snapshot {
        val file = projectFile(filesDir)
        if (!file.isFile) {
            val initial = Snapshot(emptyList(), 0, newIds())
            save(filesDir, initial)
            return initial
        }
        return try {
            val root = JSONObject(file.readText(Charsets.UTF_8))
            val idsObject = root.optJSONObject("ids") ?: JSONObject()
            val ids = PackIds(
                idsObject.optString("behaviorHeader", UUID.randomUUID().toString()),
                idsObject.optString("behaviorDataModule", UUID.randomUUID().toString()),
                idsObject.optString("behaviorScriptModule", UUID.randomUUID().toString()),
                idsObject.optString("resourceHeader", UUID.randomUUID().toString()),
                idsObject.optString("resourceModule", UUID.randomUUID().toString())
            )
            val powers = mutableListOf<GeneratedPower>()
            val array = root.optJSONArray("powers") ?: JSONArray()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val name = obj.optString("name", "Poder personalizado")
                val description = obj.optString("description", "Poder creado con MundoIA")
                val script = obj.optString("abilityScript", "")
                if (script.isBlank()) continue
                powers += GeneratedPower(
                    name,
                    description,
                    script,
                    readFiles(obj.optJSONArray("behaviorFiles")),
                    readFiles(obj.optJSONArray("resourceFiles"))
                )
            }
            Snapshot(powers, root.optInt("buildNumber", 0).coerceAtLeast(0), ids)
        } catch (_: Exception) {
            // If the local project file is damaged, do not destroy it automatically.
            // Return an empty project with new IDs; the next save creates a valid file.
            Snapshot(emptyList(), 0, newIds())
        }
    }

    private fun save(filesDir: File, snapshot: Snapshot) {
        val file = projectFile(filesDir)
        file.parentFile?.mkdirs()
        val ids = JSONObject().apply {
            put("behaviorHeader", snapshot.ids.behaviorHeader)
            put("behaviorDataModule", snapshot.ids.behaviorDataModule)
            put("behaviorScriptModule", snapshot.ids.behaviorScriptModule)
            put("resourceHeader", snapshot.ids.resourceHeader)
            put("resourceModule", snapshot.ids.resourceModule)
        }
        val powers = JSONArray()
        snapshot.powers.forEach { power ->
            powers.put(JSONObject().apply {
                put("name", power.name)
                put("description", power.description)
                put("abilityScript", power.abilityScript)
                put("behaviorFiles", writeFiles(power.behaviorFiles))
                put("resourceFiles", writeFiles(power.resourceFiles))
            })
        }
        val json = JSONObject()
            .put("format", 1)
            .put("buildNumber", snapshot.buildNumber)
            .put("ids", ids)
            .put("powers", powers)
        val temp = File(file.parentFile, "project.json.tmp")
        temp.writeText(json.toString(2), Charsets.UTF_8)
        if (file.exists() && !file.delete()) throw IllegalStateException("No se pudo actualizar la biblioteca local.")
        if (!temp.renameTo(file)) {
            temp.copyTo(file, overwrite = true)
            temp.delete()
        }
    }

    private fun readFiles(array: JSONArray?): List<GeneratedFile> {
        if (array == null) return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val path = obj.optString("path", "")
                val content = obj.optString("content", "")
                if (path.isNotBlank() && content.isNotBlank()) add(GeneratedFile(path, content))
            }
        }
    }

    private fun writeFiles(files: List<GeneratedFile>): JSONArray = JSONArray().apply {
        files.forEach { file -> put(JSONObject().put("path", file.path).put("content", file.content)) }
    }

    private fun newIds() = PackIds(
        UUID.randomUUID().toString(), UUID.randomUUID().toString(), UUID.randomUUID().toString(),
        UUID.randomUUID().toString(), UUID.randomUUID().toString()
    )

    private fun slug(value: String): String = java.text.Normalizer.normalize(value.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(28)
        .ifBlank { "poder_personalizado" }
}
