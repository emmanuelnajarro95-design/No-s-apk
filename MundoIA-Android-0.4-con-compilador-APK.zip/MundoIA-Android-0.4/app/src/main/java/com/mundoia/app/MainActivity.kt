package com.mundoia.app

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var referenceLabel: TextView
    private lateinit var descriptionInput: EditText
    private lateinit var baseUrlInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var apiVersionInput: EditText
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var generateButton: Button
    private lateinit var exportButton: Button
    private lateinit var libraryText: TextView

    private var referenceName: String? = null
    private var referenceFile: File? = null
    private var referenceContext: String? = null
    private var generatedPackage: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        restoreSettings()
        refreshLibraryStatus()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(14, 17, 26))
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(32))
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "MundoIA"
            textSize = 32f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val tagline = text("Creador de poderes para Minecraft Bedrock", 14, MUTED)
        root.addView(brand)
        root.addView(tagline, marginParams(bottom = 18))

        val notice = card()
        notice.addView(text("TU MUNDO SIGUE SIENDO TUYO", 12, ACCENT, true))
        notice.addView(text(
            "Esta versión prepara un .mcaddon a partir de tu descripción y de los archivos de pack que importes como referencia. No aloja tu mundo. La conexión directa con una partida abierta todavía no está disponible.",
            14, TEXT
        ), marginParams(top = 7))
        root.addView(notice, marginParams(bottom = 16))

        val referenceCard = card()
        referenceCard.addView(sectionTitle("1. Archivo de referencia (opcional)"))
        referenceCard.addView(text("Puedes importar un .mcaddon, .mcpack, .mcworld o .zip como referencia. MundoIA inspecciona solo manifiestos y archivos de texto de los packs; no lee bases de datos ni datos del jugador, y no modifica el mundo abierto.", 13, MUTED), marginParams(top = 6, bottom = 12))
        val pickButton = secondaryButton("Elegir mundo o addon") { chooseReferenceFile() }
        referenceCard.addView(pickButton, matchParams())
        referenceLabel = text("Todavía no has elegido ningún archivo.", 12, MUTED)
        referenceCard.addView(referenceLabel, marginParams(top = 9))
        root.addView(referenceCard, marginParams(bottom = 16))

        val powerCard = card()
        powerCard.addView(sectionTitle("2. Describe el poder"))
        powerCard.addView(text("Escribe cómo quieres que funcione. Puedes explicar controles, alcance, efectos, duración, animaciones y límites.", 13, MUTED), marginParams(top = 6, bottom = 10))
        descriptionInput = EditText(this).apply {
            hint = "Ejemplo: Quiero controlar el hielo, crear muros delante de mí, lanzar fragmentos y congelar el suelo durante unos segundos..."
            setHintTextColor(0xFF778197.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            minLines = 5
            maxLines = 9
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(0xFF171D2A.toInt(), 12)
        }
        powerCard.addView(descriptionInput, matchParams())
        root.addView(powerCard, marginParams(bottom = 16))

        val settingsCard = card()
        settingsCard.addView(sectionTitle("3. Conexión con la IA"))
        settingsCard.addView(text("La IA se conecta directamente desde el teléfono a un proveedor compatible con Chat Completions. No usamos un servidor de Minecraft. Necesitas un modelo y, si el proveedor lo exige, una clave API. La clave solo permanece en memoria mientras la app está abierta. Al generar, la descripción y el contexto permitido del addon de referencia se envían al proveedor que configures.", 13, MUTED), marginParams(top = 6, bottom = 12))
        baseUrlInput = field("Dirección API", "https://api.openai.com/v1")
        modelInput = field("Modelo", "Escribe el modelo de tu proveedor")
        apiKeyInput = field("Clave API (no se guarda)", "Pega aquí tu clave si tu proveedor la requiere", true)
        apiVersionInput = field("Versión @minecraft/server", "Ejemplo: 2.10.0")
        settingsCard.addView(label("Dirección base HTTPS"))
        settingsCard.addView(baseUrlInput, marginParams(top = 5, bottom = 9))
        settingsCard.addView(label("Modelo"))
        settingsCard.addView(modelInput, marginParams(top = 5, bottom = 9))
        settingsCard.addView(label("Clave API"))
        settingsCard.addView(apiKeyInput, marginParams(top = 5, bottom = 9))
        settingsCard.addView(label("Versión estable de @minecraft/server (predeterminada: 2.10.0)"))
        settingsCard.addView(apiVersionInput, marginParams(top = 5))
        root.addView(settingsCard, marginParams(bottom = 16))

        val actionCard = card()
        actionCard.addView(sectionTitle("4. Crear el addon"))
        statusText = text("Estado: listo cuando configures la IA.", 14, TEXT)
        actionCard.addView(statusText, marginParams(top = 8, bottom = 8))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        actionCard.addView(progress, marginParams(bottom = 10))
        generateButton = primaryButton("Generar poder con IA") { generatePower() }
        actionCard.addView(generateButton, matchParams())
        exportButton = secondaryButton("Guardar biblioteca .mcaddon") { saveGeneratedPackage() }.apply { isEnabled = false }
        actionCard.addView(exportButton, marginParams(top = 9))
        libraryText = text("Biblioteca local: 0 poderes. Los poderes creados se acumulan en un solo addon.", 12, MUTED)
        actionCard.addView(libraryText, marginParams(top = 9))
        root.addView(actionCard, marginParams(bottom = 16))

        root.addView(text(
            "IMPORTANTE: crear el archivo no lo instala dentro del mundo que ya está abierto. Debes importar el .mcaddon y activar sus packs desde la configuración del mundo. Los scripts pueden recargarse en ciertas condiciones; modelos, texturas y definiciones nuevas requieren volver a cargar el mundo. Esta versión no puede inyectar cambios en una partida abierta.",
            12, WARNING
        ))
        setContentView(scroll)
    }

    private fun refreshLibraryStatus() {
        try {
            val project = PowerProjectStore.loadSnapshot(filesDir)
            libraryText.text = "Biblioteca local: ${project.powers.size} poderes. Los poderes se acumulan en un solo addon."
            if (project.powers.isNotEmpty()) {
                statusText.text = "Biblioteca recuperada: ${project.powers.size} poderes guardados en este teléfono. Preparando la exportación actualizada…"
                val selectedApiVersion = apiVersionInput.text.toString().trim().ifBlank { "2.10.0" }
                worker.execute {
                    try {
                        val iconBytes = assets.open("power_icon.png").use { it.readBytes() }
                        val output = PowerPackBuilder.build(
                            File(filesDir, "generated"), project, selectedApiVersion, iconBytes
                        )
                        runOnUiThread {
                            generatedPackage = output
                            exportButton.isEnabled = true
                            statusText.text = "Biblioteca lista para guardar: ${project.powers.size} poderes en un solo .mcaddon."
                        }
                    } catch (error: Exception) {
                        runOnUiThread { statusText.text = "Biblioteca recuperada, pero no se pudo preparar su exportación: ${error.message}" }
                    }
                }
            }
        } catch (_: Exception) {
            libraryText.text = "No se pudo leer la biblioteca local."
        }
    }

    private fun generatePower() {
        val description = descriptionInput.text?.toString()?.trim().orEmpty()
        val baseUrl = baseUrlInput.text?.toString()?.trim().orEmpty()
        val model = modelInput.text?.toString()?.trim().orEmpty()
        val apiKey = apiKeyInput.text?.toString()?.trim().orEmpty()
        val apiVersion = apiVersionInput.text?.toString()?.trim().orEmpty().ifBlank { "2.10.0" }

        if (description.length < 12) {
            toast("Describe el poder con un poco más de detalle.")
            return
        }
        if (baseUrl.isBlank() || model.isBlank()) {
            toast("Configura la dirección de IA y el modelo primero.")
            return
        }
        saveNonSecretSettings()
        setBusy(true, "La IA está diseñando el poder y preparando los archivos…")

        worker.execute {
            try {
                val result = AiPackGenerator.generate(baseUrl, model, apiKey, description, referenceName, referenceContext)
                val project = PowerProjectStore.addPower(filesDir, result)
                val iconBytes = assets.open("power_icon.png").use { it.readBytes() }
                val output = PowerPackBuilder.build(File(filesDir, "generated"), project, apiVersion, iconBytes)
                runOnUiThread {
                    generatedPackage = output
                    libraryText.text = "Biblioteca local: ${project.powers.size} poderes. Se exporta un solo Behavior Pack + Resource Pack con todos ellos."
                    setBusy(false, "¡Biblioteca actualizada! ${result.name}\n${output.length() / 1024} KB · ${project.powers.size} poderes en el mismo addon (versión ${project.buildNumber})")
                    exportButton.isEnabled = true
                    toast("Biblioteca actualizada. Guarda el .mcaddon para importar la versión nueva.")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false, "No se pudo generar: ${e.message ?: "error desconocido"}")
                    exportButton.isEnabled = false
                }
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        statusText.text = message
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        generateButton.isEnabled = !busy
        generateButton.text = if (busy) "Generando…" else "Generar poder con IA"
    }

    private fun chooseReferenceFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream", "application/zip", "application/x-zip-compressed"
            ))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_REFERENCE)
    }

    private fun saveGeneratedPackage() {
        val packageFile = generatedPackage
        if (packageFile == null || !packageFile.exists()) {
            toast("Primero genera un addon.")
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, packageFile.name)
        }
        startActivityForResult(intent, REQUEST_SAVE)
    }

    @Deprecated("Using the Activity Result API is recommended in a production release")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQUEST_REFERENCE -> importReference(uri)
            REQUEST_SAVE -> copyGeneratedPackage(uri)
        }
    }

    private fun importReference(uri: Uri) {
        try {
            val name = queryDisplayName(uri) ?: "archivo_minecraft"
            val safeName = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(90)
            val lower = safeName.lowercase()
            if (!listOf(".mcworld", ".mcaddon", ".mcpack", ".zip").any { lower.endsWith(it) }) {
                throw IllegalArgumentException("Elige un archivo .mcworld, .mcaddon, .mcpack o .zip.")
            }
            val targetDir = File(filesDir, "references").apply { mkdirs() }
            val copied = File(targetDir, "${System.currentTimeMillis()}_$safeName")
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    copied.outputStream().use { output ->
                        val buffer = ByteArray(16 * 1024)
                        var total = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            total += read
                            if (total > MAX_REFERENCE_BYTES) {
                                throw IllegalArgumentException("El archivo supera el límite de 100 MB de esta versión.")
                            }
                            output.write(buffer, 0, read)
                        }
                    }
                } ?: throw IllegalStateException("Android no permitió leer el archivo seleccionado.")
            } catch (copyError: Exception) {
                copied.delete()
                throw copyError
            }

            val inspection = try {
                ReferenceArchiveReader.inspect(copied)
            } catch (inspectError: Exception) {
                copied.delete()
                throw IllegalArgumentException("El archivo se copió, pero no se pudo inspeccionar como paquete ZIP: ${inspectError.message}")
            }
            referenceFile?.takeIf { it.parentFile == targetDir }?.delete()
            referenceFile = copied
            referenceName = safeName
            referenceContext = inspection.promptContext
            referenceLabel.text = "Seleccionado: $safeName\n${inspection.summary}\nSe enviarán a la IA solo manifiestos y archivos de texto relevantes de los packs; no se envían bases de datos ni datos del jugador."
            statusText.text = "Referencia importada e inspeccionada."
        } catch (e: Exception) {
            toast("No se pudo abrir el archivo: ${e.message}")
        }
    }

    private fun copyGeneratedPackage(destinationUri: Uri) {
        val source = generatedPackage ?: return
        try {
            contentResolver.openOutputStream(destinationUri, "w")?.use { output ->
                source.inputStream().use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Android no permitió guardar el archivo.")
            statusText.text = "Addon guardado. Abre el .mcaddon desde Archivos y elige Minecraft para importarlo. Después activa sus paquetes en la configuración del mundo."
            toast("Archivo guardado.")
        } catch (e: Exception) {
            toast("No se pudo guardar: ${e.message}")
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else uri.lastPathSegment
        } finally {
            cursor?.close()
        }
    }

    private fun restoreSettings() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        baseUrlInput.setText(prefs.getString(KEY_BASE, "https://api.openai.com/v1"))
        modelInput.setText(prefs.getString(KEY_MODEL, ""))
        apiVersionInput.setText(prefs.getString(KEY_API_VERSION, "2.10.0"))
    }

    private fun saveNonSecretSettings() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_BASE, baseUrlInput.text.toString().trim())
            .putString(KEY_MODEL, modelInput.text.toString().trim())
            .putString(KEY_API_VERSION, apiVersionInput.text.toString().trim())
            .apply()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(CARD, 16, BORDER)
    }

    private fun sectionTitle(value: String): TextView = text(value, 17, Color.WHITE, true)

    private fun label(value: String): TextView = text(value, 12, MUTED, true)

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this)
        view.text = value
        view.textSize = size.toFloat()
        view.setTextColor(color)
        if (bold) view.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        view.setLineSpacing(dp(2).toFloat(), 1f)
        return view
    }

    private fun field(title: String, hintValue: String, password: Boolean = false): EditText {
        val view = EditText(this)
        view.hint = hintValue
        view.setHintTextColor(0xFF778197.toInt())
        view.setTextColor(Color.WHITE)
        view.textSize = 14f
        view.setSingleLine(true)
        view.setPadding(dp(12), dp(10), dp(12), dp(10))
        view.background = rounded(0xFF171D2A.toInt(), 10)
        view.inputType = if (password) {
            android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        view.contentDescription = title
        return view
    }

    private fun primaryButton(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = rounded(0xFF7062E8.toInt(), 12)
        setOnClickListener { action() }
    }

    private fun secondaryButton(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        textSize = 14f
        setTextColor(0xFFE6E9F5.toInt())
        background = rounded(0xFF252D40.toInt(), 12, 0xFF3B4560.toInt())
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun matchParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        if (top > 0) topMargin = dp(top)
        if (bottom > 0) bottomMargin = dp(bottom)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_REFERENCE = 2101
        private const val REQUEST_SAVE = 2102
        private const val MAX_REFERENCE_BYTES = 100L * 1024L * 1024L
        private const val PREFS = "mundoia_settings"
        private const val KEY_BASE = "api_base"
        private const val KEY_MODEL = "api_model"
        private const val KEY_API_VERSION = "script_api_version"
        private const val CARD = 0xFF1B2130.toInt()
        private const val BORDER = 0xFF30394D.toInt()
        private const val TEXT = 0xFFE6EAF4.toInt()
        private const val MUTED = 0xFFACB6CC.toInt()
        private const val ACCENT = 0xFFB4A9FF.toInt()
        private const val WARNING = 0xFFFFD18C.toInt()
    }
}
