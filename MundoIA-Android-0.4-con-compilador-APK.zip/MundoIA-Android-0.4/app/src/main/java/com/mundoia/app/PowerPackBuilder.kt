package com.mundoia.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.Normalizer
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Builds one persistent BP/RP pair containing the user's whole power library. */
object PowerPackBuilder {
    fun build(
        outputDirectory: File,
        project: PowerProjectStore.Snapshot,
        scriptApiVersion: String,
        iconPng: ByteArray
    ): File {
        require(project.powers.isNotEmpty()) { "La biblioteca todavía no tiene poderes." }
        require(project.powers.size <= 30) { "La biblioteca supera el máximo permitido de 30 poderes." }
        require(iconPng.isNotEmpty()) { "No se encontró el icono base de la pluma." }
        val apiVersion = parseVersion(scriptApiVersion)
        outputDirectory.mkdirs()

        val buildVersion = versionArray(project.buildNumber.coerceAtLeast(1))
        val ids = project.ids
        val bpManifest = JSONObject().apply {
            put("format_version", 2)
            put("header", JSONObject()
                .put("name", "MundoIA - Biblioteca de poderes")
                .put("description", "Biblioteca de poderes creada con MundoIA")
                .put("uuid", ids.behaviorHeader)
                .put("version", buildVersion)
                .put("min_engine_version", JSONArray().put(1).put(26).put(50)))
            put("modules", JSONArray()
                .put(JSONObject().put("type", "data").put("uuid", ids.behaviorDataModule).put("version", buildVersion))
                .put(JSONObject().put("type", "script").put("language", "javascript").put("entry", "scripts/main.js").put("uuid", ids.behaviorScriptModule).put("version", buildVersion)))
            put("dependencies", JSONArray()
                .put(JSONObject().put("module_name", "@minecraft/server").put("version", apiVersion))
                .put(JSONObject().put("uuid", ids.resourceHeader).put("version", buildVersion)))
        }
        val rpManifest = JSONObject().apply {
            put("format_version", 2)
            put("header", JSONObject()
                .put("name", "MundoIA - Recursos")
                .put("description", "Iconos y recursos de la biblioteca MundoIA")
                .put("uuid", ids.resourceHeader)
                .put("version", buildVersion)
                .put("min_engine_version", JSONArray().put(1).put(26).put(50)))
            put("modules", JSONArray().put(JSONObject()
                .put("type", "resources")
                .put("uuid", ids.resourceModule)
                .put("version", buildVersion)))
        }

        val textureData = JSONObject()
        val itemFiles = mutableListOf<Pair<String, String>>()
        val scriptImports = mutableListOf<String>()
        val scriptMap = mutableListOf<String>()
        val generatedBehaviorFiles = linkedMapOf<String, String>()
        val generatedResourceFiles = linkedMapOf<String, String>()

        project.powers.forEach { power ->
            val slug = slug(power.name)
            val itemId = "mundoia:power_$slug"
            val textureId = "mundoia_power_$slug"
            val functionAlias = "activate_$slug"
            textureData.put(textureId, JSONObject().put("textures", "textures/items/power_trigger"))
            itemFiles += "items/mundoia_$slug.json" to createPowerItem(itemId, "Pluma: ${power.name}", textureId)
            scriptImports += "import { activatePower as $functionAlias } from \"./powers/$slug.js\";"
            scriptMap += "  \"$itemId\": $functionAlias"
            generatedBehaviorFiles.putAll(namespaceFiles(power.behaviorFiles, slug))
            generatedResourceFiles.putAll(namespaceFiles(power.resourceFiles, slug))
            generatedBehaviorFiles["scripts/powers/$slug.js"] = power.abilityScript
        }

        val mainJs = buildString {
            appendLine("import { world } from \"@minecraft/server\";")
            scriptImports.forEach { appendLine(it) }
            appendLine()
            appendLine("const POWER_ACTIVATORS = {")
            appendLine(scriptMap.joinToString(",\n"))
            appendLine("};")
            appendLine()
            appendLine("world.afterEvents.itemUse.subscribe((event) => {")
            appendLine("  const itemId = event.itemStack?.typeId;")
            appendLine("  const activate = POWER_ACTIVATORS[itemId];")
            appendLine("  if (!activate) return;")
            appendLine("  const player = event.source;")
            appendLine("  if (!player || player.typeId !== \"minecraft:player\") return;")
            appendLine("  try {")
            appendLine("    activate(player);")
            appendLine("  } catch (error) {")
            appendLine("    player.sendMessage(\"§cMundoIA: no se pudo activar el poder.\");")
            appendLine("    console.warn(`[MundoIA] ${'$'}{error}`);")
            appendLine("  }")
            appendLine("});")
        }

        val behaviorPack = createZipBytes { zip ->
            addText(zip, "manifest.json", bpManifest.toString(2))
            addBytes(zip, "pack_icon.png", iconPng)
            addText(zip, "scripts/main.js", mainJs)
            itemFiles.forEach { (path, content) -> addText(zip, path, content) }
            generatedBehaviorFiles.forEach { (path, content) -> addText(zip, path, content) }
        }

        val textureAtlas = JSONObject().apply {
            put("resource_pack_name", "MundoIA - Recursos")
            put("texture_name", "atlas.items")
            put("texture_data", textureData)
        }
        val resourcePack = createZipBytes { zip ->
            addText(zip, "manifest.json", rpManifest.toString(2))
            addBytes(zip, "pack_icon.png", iconPng)
            addBytes(zip, "textures/items/power_trigger.png", iconPng)
            addText(zip, "textures/item_texture.json", textureAtlas.toString(2))
            generatedResourceFiles.forEach { (path, content) -> addText(zip, path, content) }
        }

        val packageName = "MundoIA_Biblioteca_v${project.buildNumber.coerceAtLeast(1).toString().padStart(4, '0')}.mcaddon"
        val packageFile = File(outputDirectory, packageName)
        ZipOutputStream(FileOutputStream(packageFile)).use { outer ->
            addBytes(outer, "MundoIA_BP.mcpack", behaviorPack)
            addBytes(outer, "MundoIA_RP.mcpack", resourcePack)
        }
        verifyPackage(packageFile, project.powers.size)
        return packageFile
    }

    private fun createPowerItem(identifier: String, displayName: String, textureId: String): String =
        JSONObject().apply {
            put("format_version", "1.21.60")
            put("minecraft:item", JSONObject()
                .put("description", JSONObject()
                    .put("identifier", identifier)
                    .put("menu_category", JSONObject().put("category", "equipment")))
                .put("components", JSONObject()
                    .put("minecraft:icon", JSONObject().put("textures", JSONObject().put("default", textureId)))
                    .put("minecraft:display_name", JSONObject().put("value", displayName))
                    .put("minecraft:max_stack_size", 1)
                    .put("minecraft:hand_equipped", true)
                    .put("minecraft:use_modifiers", JSONObject().put("use_duration", 0.1).put("movement_modifier", 1.0))))
        }.toString(2)

    private fun namespaceFiles(files: List<GeneratedFile>, slug: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        for (file in files) {
            val parts = file.path.replace('\\', '/').split('/')
            require(parts.size >= 2) { "Ruta generada incompleta: ${file.path}" }
            val root = parts.first()
            val nested = parts.drop(1).joinToString("/")
            val target = "$root/mundoia_$slug/$nested"
            require(target !in result) { "La IA repitió una ruta del paquete: $target" }
            result[target] = file.content
        }
        return result
    }

    private fun createZipBytes(write: (ZipOutputStream) -> Unit): ByteArray {
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use(write)
        return bytes.toByteArray()
    }

    private fun verifyPackage(file: File, expectedPowers: Int) {
        java.util.zip.ZipFile(file).use { outer ->
            val bpName = "MundoIA_BP.mcpack"
            val rpName = "MundoIA_RP.mcpack"
            check(outer.getEntry(bpName) != null && outer.getEntry(rpName) != null) {
                "El .mcaddon no contiene Behavior Pack y Resource Pack."
            }
            val bp = outer.getInputStream(outer.getEntry(bpName)).use { it.readBytes() }
            val rp = outer.getInputStream(outer.getEntry(rpName)).use { it.readBytes() }
            val bpFiles = verifyInnerPack(bp, setOf("manifest.json", "scripts/main.js"))
            val rpFiles = verifyInnerPack(rp, setOf("manifest.json", "textures/item_texture.json", "textures/items/power_trigger.png"))
            check(bpFiles.count { it.startsWith("items/mundoia_") && it.endsWith(".json") } == expectedPowers) {
                "El Behavior Pack no contiene todos los objetos activadores."
            }
            check(bpFiles.count { it.startsWith("scripts/powers/") && it.endsWith(".js") } == expectedPowers) {
                "El Behavior Pack no contiene todos los scripts de poder."
            }
            check(rpFiles.isNotEmpty())
        }
    }

    private fun verifyInnerPack(bytes: ByteArray, required: Set<String>): Set<String> {
        val found = mutableSetOf<String>()
        val jsonFiles = setOf("manifest.json", "textures/item_texture.json")
        ZipInputStream(ByteArrayInputStream(bytes)).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                if (!entry.isDirectory) {
                    found.add(entry.name)
                    if (entry.name in jsonFiles || entry.name.startsWith("items/") && entry.name.endsWith(".json")) {
                        val content = input.readBytes().toString(Charsets.UTF_8)
                        JSONObject(content)
                    }
                }
                input.closeEntry()
            }
        }
        check(found.containsAll(required)) { "Uno de los .mcpack quedó incompleto. Faltan: ${required - found}" }
        return found
    }

    private fun addBytes(zip: ZipOutputStream, path: String, content: ByteArray) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(content)
        zip.closeEntry()
    }

    private fun addText(zip: ZipOutputStream, path: String, content: String) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun parseVersion(value: String): JSONArray {
        val parts = value.trim().split('.')
        require(parts.size == 3 && parts.all { it.toIntOrNull() != null }) {
            "La versión de @minecraft/server debe tener formato mayor.menor.parche, por ejemplo 2.10.0."
        }
        return JSONArray().put(parts[0].toInt()).put(parts[1].toInt()).put(parts[2].toInt())
    }

    private fun versionArray(buildNumber: Int) = JSONArray().put(1).put(0).put(buildNumber.coerceAtLeast(1))

    private fun slug(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(28)
        .ifBlank { "poder_personalizado" }
}
