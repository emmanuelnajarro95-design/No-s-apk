cmake_minimum_required(VERSION 3.22.1)
project(je2be_android_jni LANGUAGES C CXX)

# FetchContent_Populate is needed here because the upstream desktop project
# must be added with EXCLUDE_FROM_ALL for Android. Silence its newer-policy
# deprecation on CMake versions that introduced CMP0169.
if(POLICY CMP0169)
    cmake_policy(SET CMP0169 OLD)
endif()

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

include(FetchContent)
find_package(Python3 REQUIRED COMPONENTS Interpreter)

# JE2BE Core uses CPM for its dependencies. Keep its source cache in the
# Android native build directory so the compatibility patch is repeatable.
set(CPM_SOURCE_CACHE "${CMAKE_BINARY_DIR}/cpm-source" CACHE PATH "CPM source cache" FORCE)
set(CPM_USE_NAMED_CACHE_DIRECTORIES OFF CACHE BOOL "Use CPM package hash directories" FORCE)

FetchContent_Declare(
    je2be
    GIT_REPOSITORY https://github.com/kbinani/je2be-core.git
    GIT_TAG 8dfc4de1ba5c7f72e804abea8663380c0dbd5680
    GIT_SHALLOW FALSE
)

FetchContent_GetProperties(je2be)
if(NOT je2be_POPULATED)
    FetchContent_Populate(je2be)
endif()

# EXCLUDE_FROM_ALL prevents JE2BE's desktop CLI/test executables from being
# built as part of the Android app. The static je2be library is still built
# because je2be_jni links to it.
add_subdirectory("${je2be_SOURCE_DIR}" "${je2be_BINARY_DIR}" EXCLUDE_FROM_ALL)

# Android's bionic provides pthread APIs through libc; it has no separate
# libpthread to link. Upstream adds pthread on every non-MSVC platform.
if(TARGET je2be)
    get_target_property(_JE2BE_INTERFACE_LIBS je2be INTERFACE_LINK_LIBRARIES)
    if(_JE2BE_INTERFACE_LIBS)
        list(REMOVE_ITEM _JE2BE_INTERFACE_LIBS pthread)
        set_property(TARGET je2be PROPERTY INTERFACE_LINK_LIBRARIES "${_JE2BE_INTERFACE_LIBS}")
    endif()
else()
    message(FATAL_ERROR "JE2BE Core no creó el target CMake esperado: je2be")
endif()

# Patch the exact pinned libminecraft-file source after JE2BE's CPM dependencies
# are configured, before any C++ target is compiled.
file(GLOB_RECURSE _GZ_HEADERS
    "${CPM_SOURCE_CACHE}/libminecraft-file/*/include/mcfile/stream/gz-file-input-stream.hpp")
if(NOT _GZ_HEADERS)
    message(FATAL_ERROR "No se encontró gz-file-input-stream.hpp en ${CPM_SOURCE_CACHE}")
endif()
execute_process(
    COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_LIST_DIR}/../../../../patches/fix_gzread.py" ${_GZ_HEADERS}
    RESULT_VARIABLE _PATCH_RESULT
    COMMAND_ECHO STDOUT
)
if(NOT _PATCH_RESULT EQUAL 0)
    message(FATAL_ERROR "Falló el parche de compatibilidad zlib/Android")
endif()

add_library(je2be_jni SHARED bridge.cpp)
target_compile_options(je2be_jni PRIVATE -Wall -Wextra -Wno-unused-parameter)
target_link_libraries(je2be_jni PRIVATE je2be log)
