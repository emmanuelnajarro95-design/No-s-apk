#!/usr/bin/env python3
"""Patch libminecraft-file's gz input stream for Android zlib headers.

The upstream source calls gzfread(), which is not consistently declared by
Android NDK zlib headers. gzread() is the portable zlib API for gzFile.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERN = re.compile(
    r"size_t\s+read\s*=\s*gzfread\(\s*buffer\s*,\s*1\s*,\s*size\s*,\s*fFile\s*\)\s*;"
)
REPLACEMENT = """size_t read = 0; /* JE2BE_GZREAD_PATCH */
        while (read < size) {
            const size_t remaining = size - read;
            const unsigned int request = static_cast<unsigned int>(
                std::min<size_t>(remaining, static_cast<size_t>(std::numeric_limits<int>::max())));
            const int result = gzread(fFile, static_cast<unsigned char *>(buffer) + read, request);
            if (result <= 0) {
                break;
            }
            read += static_cast<size_t>(result);
        }"""


def patch(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    if "JE2BE_GZREAD_PATCH" in source:
        print(f"Already patched: {path}")
        return
    if not PATTERN.search(source):
        if "gzread(fFile" in source:
            print(f"Already uses gzread: {path}")
            return
        raise SystemExit(f"Expected gzfread() call was not found in {path}")

    source = source.replace("#pragma once", "#pragma once\n\n#include <algorithm>\n#include <limits>", 1)
    source, count = PATTERN.subn(REPLACEMENT, source, count=1)
    if count != 1:
        raise SystemExit(f"Could not patch expected gzfread() call in {path}")
    path.write_text(source, encoding="utf-8")
    print(f"Patched: {path}")


if len(sys.argv) < 2:
    raise SystemExit("Usage: fix_gzread.py <gz-file-input-stream.hpp> [...]")

for item in sys.argv[1:]:
    patch(Path(item))
