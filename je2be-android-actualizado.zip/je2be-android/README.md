# JE2BE Android

Aplicación Android nativa para convertir mundos de Minecraft Java Edition ↔ Bedrock Edition utilizando **JE2BE Core real** (C++), integrado mediante JNI.

- Sin inteligencia artificial ni servicios remotos.
- Kotlin + Jetpack Compose.
- C++20 + Android NDK + CMake.
- WorkManager para trabajos persistentes en segundo plano.
- Android Storage Access Framework para seleccionar mundos y destino.
- ABI objetivo: `arm64-v8a`.

## Estado honesto

### Implementado en este código

- Puente JNI que utiliza las API actuales de JE2BE Core:
  - `je2be::java::Converter::Run` para Java → Bedrock.
  - `je2be::bedrock::Converter::Run` para Bedrock → Java.
- Callbacks de progreso y cancelación que implementan las interfaces reales `java::Progress` y `bedrock::Progress`.
- Selección de mundos como carpeta SAF o archivo ZIP/MCWORLD.
- Copia del mundo a un directorio temporal sin modificar el original.
- Exportación Java como ZIP y Bedrock como MCWORLD.
- Cola por carriles WorkManager; la concurrencia externa puede configurarse y cada conversión usa concurrencia interna 1 para reducir la presión de memoria.
- Detección y conversión parcial de paquetes de recursos integrados: PNG comunes de bloques/objetos, estructura básica de paquete y manifiesto/atlas Bedrock.
- Parche reproducible para sustituir la llamada incompatible `gzfread()` por lecturas `gzread()` en la dependencia `libminecraft-file` descargada por CPM.
- Workflow de GitHub Actions que compila y comprueba que el APK incluya `libje2be_jni.so` para ARM64.

### Limitaciones que todavía existen

- **La compilación Android no se ha ejecutado en este entorno.** La máquina de trabajo no dispone de Android SDK/NDK ni Gradle instalados y no tiene conexión de red para descargar dependencias. GitHub Actions debe confirmar la primera compilación.
- La conversión de Resource Packs cubre un subconjunto básico de texturas PNG de bloques y objetos. No convierte completamente modelos 3D, blockstates, predicates, shaders, fuentes, sonidos, animaciones, geometría de entidades, render controllers ni referencias personalizadas.
- Los paquetes Bedrock convertidos a Java se dejan en `converted-resource-packs/` dentro del ZIP de salida; Java no los activa automáticamente desde el mundo.
- Los paquetes globales instalados fuera del mundo no se detectan automáticamente. La conversión automática solo examina directorios de recursos integrados en el mundo.
- WorkManager puede reiniciar un trabajo que el sistema Android interrumpa, pero JE2BE no expone un punto de reanudación a mitad de conversión; el trabajo puede empezar otra vez desde cero.
- La concurrencia de varias instancias del motor depende del consumo real de memoria del teléfono. Si hay cierres por memoria, reduce el número de conversiones simultáneas a 1.
- No se ha probado todavía el APK en un dispositivo Android real ni se ha verificado una conversión completa con mundos reales de prueba.

## Compilación con GitHub Actions

1. Sube el contenido de esta carpeta a la raíz de un repositorio GitHub.
2. Abre **Actions**.
3. Ejecuta **Build JE2BE Android APK** o realiza un push a `main`.
4. Si el trabajo termina correctamente, descarga el artifact `JE2BE-Android-ARM64-debug`.

El workflow instala JDK 17, Android SDK 34, NDK `26.3.11579264` y CMake `3.22.1`, y usa Gradle 8.9.

## Compilación local

Requisitos: JDK 17, Android SDK con `cmdline-tools/latest`, `git`, `python3`, `curl`, `unzip`, y un host Linux/macOS/WSL.

```bash
ANDROID_HOME=/ruta/al/android-sdk ./build.sh
```

Salida esperada: `app/build/outputs/apk/debug/app-debug.apk`.

## Licencias

El proyecto y la integración están sujetos a GPL-3.0 por JE2BE Core. Conserva `LICENSE` y revisa las licencias de cada dependencia descargada por CPM antes de redistribuir APKs.

## Verificaciones realizadas en esta entrega

- El puente C++ pasó una comprobación de sintaxis usando declaraciones de prueba que reflejan las firmas de la API oficial consultada. Esto **no** equivale a compilar todo JE2BE Core.
- CMake configuró y construyó el target JNI contra un Core simulado; también se comprobó que el ejecutable de escritorio queda fuera de la compilación Android. Esto **no** valida el enlace final con todas las dependencias reales del Core.
- `ResourcePackConverter.kt` compiló con `kotlinc` y pasó una prueba de humo de conversión de carpetas de paquetes en ambos sentidos.
- El parche gzip se probó con una cabecera de prueba y se verificó que se puede aplicar dos veces sin duplicar cambios.
- El manifiesto Android se validó como XML y el workflow se validó como YAML.

**No se generó ni se probó un APK Android real en este entorno.** No hay Android SDK/NDK ni Gradle instalados aquí y el entorno no pudo descargar las dependencias del motor. La primera compilación completa debe confirmarse en GitHub Actions; es posible que aún aparezcan incompatibilidades del NDK o de dependencias nativas que solo se detectan al compilar el Core real.
