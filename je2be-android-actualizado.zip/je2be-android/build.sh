#!/usr/bin/env bash
# Compilación local en Linux/macOS/WSL. Uso: ANDROID_HOME=/ruta/al/sdk ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Define ANDROID_HOME con la carpeta del Android SDK}"

for tool in java git python3 unzip curl; do
  command -v "$tool" >/dev/null 2>&1 || { echo "Falta la herramienta: $tool"; exit 1; }
done
java -version 2>&1 | grep -q '"17\.' || { echo "Se necesita JDK 17"; exit 1; }

SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
[ -x "$SDKMANAGER" ] || { echo "No encuentro $SDKMANAGER"; exit 1; }
set +o pipefail
yes | "$SDKMANAGER" --licenses >/dev/null
LICENSE_STATUS=${PIPESTATUS[1]}
set -o pipefail
if [ "$LICENSE_STATUS" -ne 0 ]; then
  exit "$LICENSE_STATUS"
fi
"$SDKMANAGER" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  "ndk;26.3.11579264" \
  "cmake;3.22.1"

GRADLE_VERSION="8.9"
GRADLE_HOME="$PWD/.tools/gradle-$GRADLE_VERSION"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  mkdir -p .tools
  curl -fsSL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o ".tools/gradle-$GRADLE_VERSION-bin.zip"
  unzip -q -o ".tools/gradle-$GRADLE_VERSION-bin.zip" -d .tools
fi

CMAKE_BUILD_PARALLEL_LEVEL=2 "$GRADLE_HOME/bin/gradle" :app:testDebugUnitTest :app:assembleDebug --no-daemon --stacktrace
APK="app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
unzip -l "$APK" | grep -q 'lib/arm64-v8a/libje2be_jni.so' || {
  echo "El APK no contiene libje2be_jni.so para ARM64."
  exit 1
}
echo "APK compilado y verificado: $APK"
