package app.je2be.android

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import app.je2be.android.conversion.ConversionDirection
import app.je2be.android.conversion.ConvertWorldWorker
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val workManager = remember { WorkManager.getInstance(applicationContext) }
                val jobs by workManager.getWorkInfosByTagLiveData(TAG).observeAsState(emptyList())
                var inputUri by remember { mutableStateOf<Uri?>(null) }
                var outputUri by remember { mutableStateOf<Uri?>(null) }
                var title by remember { mutableStateOf("Mi mundo") }
                var direction by remember { mutableStateOf(ConversionDirection.JAVA_TO_BEDROCK) }
                val inputPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                    inputUri = uri
                    keepAccess(uri, write = false)
                }
                val outputPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                    outputUri = uri
                    keepAccess(uri, write = true)
                }
                val multiZipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
                    val destination = outputUri
                    if (destination != null) {
                        uris.forEachIndexed { index, uri ->
                            keepAccess(uri, write = false)
                            enqueue(workManager, uri, destination, direction, displayName(uri).ifBlank { "Mundo-${index + 1}" })
                        }
                    }
                }

                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("JE2BE Android", style = MaterialTheme.typography.headlineMedium)
                        Text("Conversor de mundos Minecraft · versión experimental")
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("1. Dirección", style = MaterialTheme.typography.titleMedium)
                                ConversionDirection.entries.forEach { option ->
                                    Row {
                                        RadioButton(selected = direction == option, onClick = { direction = option })
                                        Text(option.label, modifier = Modifier.padding(top = 12.dp))
                                    }
                                }
                                Text("2. Mundo de entrada", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(
                                    value = title,
                                    onValueChange = { title = it },
                                    label = { Text("Nombre para la conversión") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                                OutlinedButton(onClick = { inputPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (inputUri == null) "Elegir carpeta del mundo" else "Cambiar carpeta seleccionada")
                                }
                                Button(
                                    onClick = {
                                        if (inputUri != null && outputUri != null) {
                                            enqueue(workManager, inputUri!!, outputUri!!, direction, title)
                                            inputUri = null
                                        }
                                    },
                                    enabled = inputUri != null && outputUri != null,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Añadir carpeta a la cola") }
                                OutlinedButton(
                                    onClick = { multiZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) },
                                    enabled = outputUri != null,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Añadir varios ZIP / MCWORLD") }
                                Text("Puedes seleccionar varios archivos de mundo y ponerlos en cola de una vez.", style = MaterialTheme.typography.bodySmall)
                                Text("3. Carpeta para guardar", style = MaterialTheme.typography.titleMedium)
                                OutlinedButton(onClick = { outputPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (outputUri == null) "Elegir carpeta de salida" else "Destino seleccionado")
                                }
                            }
                        }
                        Text("Cola de conversiones (${jobs.size})", style = MaterialTheme.typography.titleLarge)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(jobs, key = { it.id }) { info -> JobCard(info) }
                        }
                    }
                }
            }
        }
    }

    private fun keepAccess(uri: Uri?, write: Boolean) {
        if (uri == null) return
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            (if (write) android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
    }

    private fun enqueue(workManager: WorkManager, source: Uri, destination: Uri, direction: ConversionDirection, name: String) {
        val workId = UUID.randomUUID()
        val data = Data.Builder()
            .putString(ConvertWorldWorker.KEY_INPUT_URI, source.toString())
            .putString(ConvertWorldWorker.KEY_OUTPUT_URI, destination.toString())
            .putString(ConvertWorldWorker.KEY_DIRECTION, direction.name)
            .putString(ConvertWorldWorker.KEY_TITLE, name)
            .build()
        val request = OneTimeWorkRequestBuilder<ConvertWorldWorker>()
            .setId(workId)
            .setInputData(data)
            .addTag(TAG)
            .build()
        workManager.enqueueUniqueWork("je2be-$workId", ExistingWorkPolicy.KEEP, request)
    }

    private fun displayName(uri: Uri): String = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0)?.substringBeforeLast('.') ?: "Mundo" else "Mundo" }
        ?: "Mundo"

    @Composable
    private fun JobCard(info: WorkInfo) {
        val progress = info.progress.getInt(ConvertWorldWorker.KEY_PROGRESS, if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0)
        val stage = info.progress.getString(ConvertWorldWorker.KEY_STAGE) ?: info.state.name
        val assistant = info.progress.getString(ConvertWorldWorker.KEY_AI)
            ?: info.outputData.getString(ConvertWorldWorker.KEY_AI)
        val error = info.outputData.getString(ConvertWorldWorker.KEY_ERROR)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(info.inputData.getString(ConvertWorldWorker.KEY_TITLE) ?: "Mundo", style = MaterialTheme.typography.titleMedium)
                Text(info.state.name)
                Text(stage)
                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                Text("$progress%", style = MaterialTheme.typography.labelMedium)
                if (!assistant.isNullOrBlank()) Text("Asistente local: $assistant", style = MaterialTheme.typography.bodySmall)
                if (!error.isNullOrBlank()) Text("Error: $error", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    companion object { private const val TAG = "je2be-job" }
}
