package app.je2be.android

import android.app.Application
import androidx.work.Configuration

class Je2beApplication : Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMaxSchedulerLimit(10)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
