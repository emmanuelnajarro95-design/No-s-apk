package app.je2be.android.conversion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import app.je2be.android.assistant.LocalWorldAssistant
import app.je2be.android.storage.SafStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class ConvertWorldWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    private val assistant = LocalWorldAssistant()

    override suspend fun doWork(): Result {
        val queuedTitle = inputData.getString(KEY_TITLE) ?: "Mundo"
        setForeground(createForegroundInfo("En cola: $queuedTitle", 0))
        return ConversionGate.semaphore.withPermit {
            withContext(Dispatchers.IO) {
        val input = inputData.getString(KEY_INPUT_URI) ?: return@withContext Result.failure()
        val output = inputData.getString(KEY_OUTPUT_URI) ?: return@withContext Result.failure()
        val direction = inputData.getString(KEY_DIRECTION) ?: return@withContext Result.failure()
        val title = inputData.getString(KEY_TITLE) ?: "Mundo"
        val workDir = File(applicationContext.cacheDir, "je2be/$id")
        val sourceDir = File(workDir, "source")
        val convertedDir = File(workDir, "converted")

        try {
            if (!NativeBridge.isAvailable) return@withContext Result.failure(workDataOf(KEY_ERROR to "El motor nativo JE2BE no está incluido en este APK."))
            val source = SafStorage.importUri(applicationContext.contentResolver, android.net.Uri.parse(input), sourceDir)
            val diagnostics = assistant.inspectWorld(source)
            setProgress(workDataOf(KEY_PROGRESS to 3, KEY_STAGE to "Analizando mundo", KEY_AI to diagnostics.joinToString(" ")))

            val isJava = direction == ConversionDirection.JAVA_TO_BEDROCK.name
            val expected = if (isJava) {
                File(source, "region").isDirectory
            } else {
                File(source, "db").isDirectory
            }
            if (!File(source, "level.dat").isFile || !expected) {
                return@withContext Result.failure(workDataOf(KEY_ERROR to "La carpeta seleccionada no parece ser un mundo ${if (isJava) "Java" else "Bedrock"}.", KEY_AI to diagnostics.joinToString(" ")))
            }

            convertedDir.mkdirs()
            val result = NativeBridge.convert(
                source.absolutePath,
                convertedDir.absolutePath,
                isJava,
                object : NativeProgressListener {
                    override fun onNativeProgress(percent: Int, stage: String) {
                        val value = percent.coerceIn(0, 99)
                        setProgressAsync(workDataOf(KEY_PROGRESS to value, KEY_STAGE to stage, KEY_AI to assistant.explain(stage, value, diagnostics)))
                        setForegroundAsync(createForegroundInfo("$title · $stage", value))
                    }
                }
            )
            if (result != null) return@withContext Result.failure(workDataOf(KEY_ERROR to result, KEY_AI to "El motor JE2BE informó un error. El mundo original no se modifica."))

            val report = JSONObject().apply {
                put("app", "JE2BE Android")
                put("version", "0.1.0-alpha")
                put("direction", direction)
                put("world", title)
                put("texture_pack_scan", diagnostics)
                put("texture_pack_conversion", "Aún no implementada: el motor JE2BE de mundos no convierte por sí solo paquetes Java resource pack a archivos Bedrock .mcpack.")
            }
            val safeName = title.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(48).ifBlank { "ConvertedWorld" }
            val extension = if (isJava) "mcworld" else "zip"
            val archive = File(workDir, "$safeName.$extension")
            val reportFile = File(workDir, "$safeName-conversion-report.json")
            reportFile.writeText(report.toString(2))
            SafStorage.archiveDirectory(convertedDir, archive)
            SafStorage.exportFile(applicationContext.contentResolver, archive, android.net.Uri.parse(output))
            SafStorage.exportFile(applicationContext.contentResolver, reportFile, android.net.Uri.parse(output))
            setProgress(workDataOf(KEY_PROGRESS to 100, KEY_STAGE to "Completado", KEY_AI to assistant.explain("Completado", 100)))
            Result.success(workDataOf(KEY_OUTPUT_NAME to safeName))
        } catch (e: Exception) {
            Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Error desconocido"), KEY_AI to "La conversión se detuvo. El mundo original permanece intacto."))
        } finally {
            workDir.deleteRecursively()
        }
            }
        }
    }

    private fun createForegroundInfo(text: String, progress: Int): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Conversiones JE2BE", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("JE2BE Android")
            .setContentText(text)
            .setProgress(100, progress, progress <= 0)
            .setOngoing(true)
            .build()
        val notificationId = (id.hashCode() and 0x7fffffff).coerceAtLeast(1)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(notificationId, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(notificationId, notification)
    }

    companion object {
        const val KEY_INPUT_URI = "input_uri"
        const val KEY_OUTPUT_URI = "output_uri"
        const val KEY_DIRECTION = "direction"
        const val KEY_TITLE = "title"
        const val KEY_PROGRESS = "progress"
        const val KEY_STAGE = "stage"
        const val KEY_AI = "ai_message"
        const val KEY_ERROR = "error"
        const val KEY_OUTPUT_NAME = "output_name"
        const val CHANNEL_ID = "je2be_conversion"
    }
}
