package app.je2be.android.storage

import android.content.ContentResolver
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.io.BufferedOutputStream

object SafStorage {
    fun importUri(resolver: ContentResolver, uri: Uri, destination: File): File {
        destination.deleteRecursively()
        destination.mkdirs()
        val document = runCatching { DocumentFile.fromTreeUri(resolver, uri) }.getOrNull()
        if (document != null && document.isDirectory) {
            copyDocumentTree(resolver, document, destination)
            return findWorldRoot(destination)
        }

        val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
            ?: "import.bin"
        val staged = File(destination, name)
        resolver.openInputStream(uri)?.use { input -> FileOutputStream(staged).use { output -> input.copyTo(output) } }
            ?: error("Android no pudo abrir el archivo seleccionado.")
        if (name.endsWith(".zip", true) || name.endsWith(".mcworld", true)) {
            val extracted = File(destination, "extracted")
            extracted.mkdirs()
            unzipSafely(staged, extracted)
            staged.delete()
            return findWorldRoot(extracted)
        }
        error("Formato no compatible. Selecciona una carpeta de mundo o un archivo ZIP/MCWORLD.")
    }

    private fun copyDocumentTree(resolver: ContentResolver, source: DocumentFile, target: File) {
        source.listFiles().forEach { child ->
            val safeName = child.name?.takeIf { it.isNotBlank() && it != "." && it != ".." } ?: return@forEach
            val output = File(target, safeName)
            if (child.isDirectory) {
                output.mkdirs()
                copyDocumentTree(resolver, child, output)
            } else {
                resolver.openInputStream(child.uri)?.use { input -> FileOutputStream(output).use { stream -> input.copyTo(stream) } }
            }
        }
    }

    private fun unzipSafely(zipFile: File, outputDir: File) {
        val root = outputDir.canonicalFile
        ZipInputStream(FileInputStream(zipFile)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val target = File(outputDir, entry.name).canonicalFile
                require(target.path == root.path || target.path.startsWith(root.path + File.separator)) {
                    "El ZIP contiene una ruta no válida."
                }
                if (entry.isDirectory) target.mkdirs() else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { output -> zip.copyTo(output) }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }

    private fun findWorldRoot(folder: File): File {
        if (File(folder, "level.dat").isFile) return folder
        val children = folder.listFiles()?.filter { it.isDirectory } ?: emptyList()
        return children.firstOrNull { File(it, "level.dat").isFile } ?: folder
    }

    fun archiveDirectory(source: File, archive: File) {
        archive.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(archive))).use { zip ->
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(source).invariantSeparatorsPath
                zip.putNextEntry(java.util.zip.ZipEntry(relative))
                FileInputStream(file).use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    fun exportFile(resolver: ContentResolver, source: File, destinationTree: Uri) {
        val parent = DocumentFile.fromTreeUri(resolver, destinationTree)
            ?: error("No se puede acceder a la carpeta de destino.")
        val mime = when (source.extension.lowercase()) {
            "mcworld" -> "application/octet-stream"
            "zip" -> "application/zip"
            "json" -> "application/json"
            else -> "application/octet-stream"
        }
        val target = parent.createFile(mime, source.name)
            ?: error("No se pudo crear el archivo de salida ${source.name}.")
        resolver.openOutputStream(target.uri)?.use { output ->
            FileInputStream(source).use { input -> input.copyTo(output) }
        } ?: error("No se pudo escribir el archivo de salida.")
    }

}
