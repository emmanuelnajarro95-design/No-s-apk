package app.je2be.android.conversion

import kotlinx.coroutines.sync.Semaphore

/** Prevents several large worlds from exhausting phone RAM at the same time. */
object ConversionGate {
    val semaphore = Semaphore(2)
}
