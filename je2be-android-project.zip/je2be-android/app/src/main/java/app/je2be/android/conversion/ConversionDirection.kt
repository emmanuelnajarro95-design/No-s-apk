package app.je2be.android.conversion

enum class ConversionDirection(val label: String, val nativeValue: Boolean) {
    JAVA_TO_BEDROCK("Java → Bedrock", true),
    BEDROCK_TO_JAVA("Bedrock → Java", false)
}
