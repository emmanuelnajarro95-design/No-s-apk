package app.je2be.android.conversion

interface NativeProgressListener {
    fun onNativeProgress(percent: Int, stage: String)
}

object NativeBridge {
    val isAvailable: Boolean = runCatching {
        System.loadLibrary("je2be_jni")
    }.isSuccess

    external fun convert(
        inputDirectory: String,
        outputDirectory: String,
        javaToBedrock: Boolean,
        listener: NativeProgressListener
    ): String?
}
