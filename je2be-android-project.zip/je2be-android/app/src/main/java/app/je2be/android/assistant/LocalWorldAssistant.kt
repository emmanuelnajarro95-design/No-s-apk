package app.je2be.android.assistant

import java.io.File

/**
 * Private, on-device diagnostic observer. It receives conversion events and
 * file/pack scan results; it never uploads world files or reads their contents
 * beyond metadata required for conversion diagnostics.
 */
class LocalWorldAssistant {
    fun inspectWorld(root: File): List<String> {
        val notes = mutableListOf<String>()
        val levelDat = File(root, "level.dat")
        val bedrockDb = File(root, "db")
        val javaRegions = File(root, "region")
        when {
            levelDat.exists() && bedrockDb.isDirectory -> notes += "Estructura detectada: mundo Bedrock."
            levelDat.exists() && javaRegions.isDirectory -> notes += "Estructura detectada: mundo Java."
            levelDat.exists() -> notes += "Se encontró level.dat, pero falta confirmar la carpeta de regiones o db."
            else -> notes += "No se encontró level.dat en la raíz seleccionada. Comprueba que elegiste la carpeta del mundo."
        }

        val javaPack = File(root, "resources.zip")
        val bedrockPackManifest = File(root, "world_resource_packs.json")
        val embeddedPacks = File(root, "resource_packs")
        val javaPacks = File(root, "resourcepacks")
        if (javaPack.isFile) notes += "Se detectó resources.zip asociado al mundo."
        if (bedrockPackManifest.isFile) notes += "El mundo incluye world_resource_packs.json; puede referenciar paquetes externos."
        if (embeddedPacks.isDirectory) notes += "Se encontró una carpeta resource_packs dentro del mundo."
        if (javaPacks.isDirectory) notes += "Se encontró una carpeta resourcepacks dentro del mundo."
        if (!javaPack.exists() && !bedrockPackManifest.exists() && !embeddedPacks.exists() && !javaPacks.exists()) {
            notes += "No se detectó un paquete de texturas integrado. Los paquetes globales de Minecraft pueden estar fuera de la carpeta del mundo."
        }
        return notes
    }

    fun explain(stage: String, percent: Int, observations: List<String> = emptyList()): String {
        val packObservation = observations.firstOrNull {
            it.contains("paquete", ignoreCase = true) || it.contains("resource_packs", ignoreCase = true)
        }
        val packContext = when {
            packObservation != null -> " También detecté esta referencia de recursos: $packObservation"
            else -> " No he encontrado un paquete de texturas integrado en la carpeta del mundo; puede estar instalado globalmente en Minecraft."
        }
        val status = when {
            percent >= 100 -> "Conversión finalizada. Revisa el informe y abre el mundo convertido en Minecraft."
            percent >= 70 -> "El motor está terminando la conversión y los ajustes del mundo: $stage."
            percent >= 25 -> "Estoy observando el motor JE2BE: $stage ($percent%)."
            percent > 0 -> "El trabajo sigue activo: $stage ($percent%). Puedes salir de la pantalla; WorkManager continúa la tarea."
            else -> "Trabajo en cola. Se iniciará cuando haya espacio de procesamiento."
        }
        return status + if (percent >= 100) "" else packContext
    }
}
