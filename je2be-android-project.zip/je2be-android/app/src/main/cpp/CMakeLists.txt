cmake_minimum_required(VERSION 3.22.1)
project(je2be_jni LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

include(FetchContent)

# Android's pthread API is provided by bionic/libc. A no-op CMake target keeps
# upstream's desktop-oriented `pthread` link item from becoming -lpthread.
if(ANDROID AND NOT TARGET pthread)
    add_library(pthread INTERFACE)
endif()

FetchContent_Declare(
    je2be_core
    GIT_REPOSITORY https://github.com/kbinani/je2be-core.git
    GIT_TAG 8dfc4de1ba5c7f72e804abea8663380c0dbd5680
    GIT_SHALLOW FALSE
)
FetchContent_GetProperties(je2be_core)
if(NOT je2be_core_POPULATED)
    FetchContent_Populate(je2be_core)
    add_subdirectory(${je2be_core_SOURCE_DIR} ${je2be_core_BINARY_DIR} EXCLUDE_FROM_ALL)
endif()

add_library(je2be_jni SHARED native-lib.cpp)
target_link_libraries(je2be_jni PRIVATE je2be android log)
