#include <jni.h>
#include <android/log.h>
#include <je2be.hpp>
#include <filesystem>
#include <mutex>
#include <string>

namespace {
constexpr char kTag[] = "JE2BE-JNI";

std::string fromJava(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

class JavaCallback {
public:
    JavaCallback(JNIEnv *env, jobject listener) {
        if (!listener) return;
        env->GetJavaVM(&fVm);
        fListener = env->NewGlobalRef(listener);
        jclass cls = env->GetObjectClass(listener);
        fMethod = env->GetMethodID(cls, "onNativeProgress", "(ILjava/lang/String;)V");
        env->DeleteLocalRef(cls);
        if (env->ExceptionCheck()) { env->ExceptionClear(); fMethod = nullptr; }
    }

    ~JavaCallback() {
        if (!fVm || !fListener) return;
        JNIEnv *env = nullptr;
        bool attached = false;
        if (fVm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
            if (fVm->AttachCurrentThread(&env, nullptr) == JNI_OK) attached = true;
        }
        if (env) env->DeleteGlobalRef(fListener);
        if (attached) fVm->DetachCurrentThread();
    }

    void send(int percent, char const *stage) {
        if (!fVm || !fListener || !fMethod) return;
        std::lock_guard<std::mutex> lock(fMutex);
        std::string currentStage = stage ? stage : "Convirtiendo";
        if (percent == fLastPercent && currentStage == fLastStage) return;
        fLastPercent = percent;
        fLastStage = currentStage;
        JNIEnv *env = nullptr;
        bool attached = false;
        if (fVm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
            if (fVm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
            attached = true;
        }
        jstring label = env->NewStringUTF(stage ? stage : "Convirtiendo");
        env->CallVoidMethod(fListener, fMethod, static_cast<jint>(percent), label);
        env->DeleteLocalRef(label);
        if (env->ExceptionCheck()) {
            __android_log_print(ANDROID_LOG_WARN, kTag, "Progress callback raised an exception");
            env->ExceptionClear();
        }
        if (attached) fVm->DetachCurrentThread();
    }

private:
    JavaVM *fVm = nullptr;
    jobject fListener = nullptr;
    jmethodID fMethod = nullptr;
    std::mutex fMutex;
    int fLastPercent = -1;
    std::string fLastStage;
};

class JavaProgress final : public je2be::java::Progress {
public:
    explicit JavaProgress(JavaCallback &callback) : fCallback(callback) {}
    bool reportConvert(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
        fCallback.send(p.fDen ? static_cast<int>(p.toD() * 80.0) : 0, "Convirtiendo chunks Java"); return true;
    }
    bool reportEntityPostProcess(je2be::Rational<je2be::u64> const &p) override {
        fCallback.send(80 + (p.fDen ? static_cast<int>(p.toD() * 10.0) : 0), "Procesando entidades"); return true;
    }
    bool reportCompaction(je2be::Rational<je2be::u64> const &p) override {
        fCallback.send(90 + (p.fDen ? static_cast<int>(p.toD() * 9.0) : 0), "Finalizando mundo"); return true;
    }
private:
    JavaCallback &fCallback;
};

class BedrockProgress final : public je2be::bedrock::Progress {
public:
    explicit BedrockProgress(JavaCallback &callback) : fCallback(callback) {}
    bool reportConvert(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
        fCallback.send(p.fDen ? static_cast<int>(p.toD() * 75.0) : 0, "Convirtiendo chunks Bedrock"); return true;
    }
    bool reportTerraform(je2be::Rational<je2be::u64> const &p, je2be::u64) override {
        fCallback.send(75 + (p.fDen ? static_cast<int>(p.toD() * 24.0) : 0), "Ajustando terreno y bloques"); return true;
    }
private:
    JavaCallback &fCallback;
};

std::string formatError(je2be::Status const &status) {
    auto error = status.error();
    if (!error) return "Error desconocido del motor JE2BE";
    std::string result = error->fWhat.empty() ? "La conversión JE2BE falló" : error->fWhat;
    for (auto const &where : error->fTrace) result += "\n" + where.fFile + ":" + std::to_string(where.fLine);
    return result;
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_app_je2be_android_conversion_NativeBridge_convert(
    JNIEnv *env, jobject, jstring inputPath, jstring outputPath, jboolean javaToBedrock, jobject listener) {
    try {
        auto input = std::filesystem::u8path(fromJava(env, inputPath));
        auto output = std::filesystem::u8path(fromJava(env, outputPath));
        if (!std::filesystem::is_directory(input)) return env->NewStringUTF("La carpeta de entrada no existe.");
        std::filesystem::create_directories(output);
        JavaCallback callback(env, listener);
        je2be::Status status;
        if (javaToBedrock == JNI_TRUE) {
            je2be::java::Options options;
            options.fTempDirectory = output.parent_path() / "je2be-java-temp";
            options.fDbTempDirectory = output.parent_path() / "je2be-db-temp";
            std::filesystem::create_directories(*options.fTempDirectory);
            std::filesystem::create_directories(*options.fDbTempDirectory);
            JavaProgress progress(callback);
            status = je2be::java::Converter::Run(input, output, options, 1, &progress);
        } else {
            je2be::bedrock::Options options;
            options.fTempDirectory = output.parent_path() / "je2be-bedrock-temp";
            std::filesystem::create_directories(*options.fTempDirectory);
            BedrockProgress progress(callback);
            status = je2be::bedrock::Converter::Run(input, output, options, 1, &progress);
        }
        if (!status.ok()) {
            auto message = formatError(status);
            return env->NewStringUTF(message.c_str());
        }
        callback.send(100, "Conversión completada");
        return nullptr;
    } catch (std::exception const &e) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "Native conversion error: %s", e.what());
        return env->NewStringUTF(e.what());
    } catch (...) {
        return env->NewStringUTF("Error nativo no identificado.");
    }
}
