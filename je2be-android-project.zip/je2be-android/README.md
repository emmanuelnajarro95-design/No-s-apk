# JE2BE Android

Port Android nativo en desarrollo para convertir mundos Minecraft Java Edition ↔ Bedrock Edition usando el motor C++ de JE2BE Core.

> **Estado: prototipo de integración, no es todavía un APK listo para usar.** La interfaz, la cola de trabajos, el acceso SAF, el worker en segundo plano, el puente JNI y el flujo de CI están preparados. La compilación NDK/Android no se pudo ejecutar en el entorno de creación (no tiene Android SDK, Gradle ni acceso de red al contenedor), por lo que el primer resultado de GitHub Actions debe considerarse la prueba real de compatibilidad.

## Funciones preparadas

- Aplicación Android nativa en Kotlin + Jetpack Compose; no es una página web metida en un WebView.
- Integración C++20 con las API públicas `je2be::java::Converter::Run` y `je2be::bedrock::Converter::Run` mediante JNI.
- Conversiones Java → Bedrock y Bedrock → Java.
- Entrada por carpeta de mundo y por archivos ZIP/MCWORLD.
- Cola persistente de trabajos con WorkManager, notificación de progreso y hasta dos trabajos activos según el límite del scheduler.
- El motor recibe concurrencia interna `1` por trabajo para reducir la presión de memoria; el paralelismo se hace entre trabajos.
- Exportación mediante Android Storage Access Framework: `.mcworld` listo para importar en Bedrock, o `.zip` del mundo Java.
- Analizador local que observa las etapas, progreso, errores y presencia de referencias de paquetes de recursos. No envía mundos a ningún servidor.
- Informe `je2be-android-report.json` en cada salida.
- GitHub Actions compila un APK de depuración y lo publica como artefacto del workflow.

## Lo que todavía falta antes de llamarlo completo

1. **Compilar y probar el motor JE2BE en Android NDK.** El core usa C++20 y varias dependencias nativas; la primera ejecución de CI puede revelar incompatibilidades o ajustes de CMake/NDK.
2. **Conversión real de paquetes de texturas.** JE2BE Core convierte los datos del mundo. La app detecta `resources.zip`, `resourcepacks`, `resource_packs` y `world_resource_packs.json`, pero aún no convierte las texturas ni transforma los paquetes en `.mcpack`. Un archivo `world_resource_packs.json` puede referenciar un paquete global que no esté dentro del mundo; el usuario deberá facilitar ese paquete por separado.
3. **Asistente IA generativo.** El asistente actual es local y basado en reglas: interpreta eventos/progreso y avisa sobre problemas habituales. No es un modelo de lenguaje ni tiene acceso irrestricto a los archivos privados. Un modelo real deberá añadirse con permisos explícitos y límites de privacidad.
4. **Pruebas con mundos reales.** Probar copias de mundos Java y Bedrock de distintas versiones, dimensiones, entidades, inventarios y mundos grandes. Nunca usar el único original como prueba.
5. **Cancelación y recuperación avanzada.** WorkManager conserva los trabajos; aún falta conectar una cancelación segura del motor C++ y un mecanismo completo de reanudación tras un cierre inesperado.

## Requisitos de compilación

- JDK 17
- Gradle 8.7
- Android SDK Platform 35
- Android NDK `27.0.12077973`
- CMake `3.22.1`
- Conexión a internet para descargar JE2BE Core y sus dependencias durante la compilación

Comando:

```bash
gradle :app:assembleDebug
```

APK generado:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Compilación automática en GitHub

El workflow `.github/workflows/android-apk.yml` ejecuta la compilación en cada push/PR y también puede iniciarse manualmente desde **Actions → Build Android APK → Run workflow**. Al terminar, el APK se encuentra en **Artifacts → JE2BE-Android-debug-apk**.

Para usarlo, crea un repositorio vacío en tu cuenta, sube el contenido de esta carpeta a la rama `main` y habilita GitHub Actions. El conector de GitHub disponible durante la preparación permite leer repositorios y modificar archivos existentes, pero no ofrece una acción para crear repositorios nuevos; además, la cuenta vinculada no tenía repositorios visibles en ese momento.

## Estructura

```text
app/
  src/main/
    cpp/                 # CMake + JNI + JE2BE Core
    java/app/je2be/android/
      assistant/         # Observador local de conversiones
      conversion/        # WorkManager y puente JNI
      storage/           # Importación/exportación SAF y ZIP seguro
      MainActivity.kt    # UI Android
.github/workflows/      # Build APK
```

## Licencia

La integración con JE2BE Core está sujeta a GPL-3.0. Lee `LICENSE` y `THIRD_PARTY_NOTICES.md` antes de distribuir APKs modificados.
