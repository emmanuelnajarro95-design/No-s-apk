# Roadmap

- [x] Android native UI scaffold
- [x] Java ↔ Bedrock JNI calls against upstream public API
- [x] SAF folder import/export
- [x] ZIP/MCWORLD extraction with path traversal protection
- [x] WorkManager background queue and foreground notification
- [x] Two-job scheduler cap for multi-world processing
- [x] Local diagnostic observer and structured conversion report
- [x] GitHub Actions APK workflow
- [ ] First successful Android NDK CI build
- [ ] Real-device smoke tests on arm64 Android
- [ ] Bedrock/Java resource-pack converter integration
- [ ] Pack extraction, mapping, texture conversion, manifest + mcpack packaging
- [ ] A genuine on-device or opt-in hosted LLM assistant with explicit privacy controls
- [ ] Native cancellation and restart-safe job reconciliation
- [ ] Conversion test corpus and regression tests
