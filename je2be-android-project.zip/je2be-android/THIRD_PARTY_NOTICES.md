# Third-party notices

## JE2BE Core

- Project: https://github.com/kbinani/je2be-core
- License: GNU GPL-3.0
- Integration: C++20 library linked through JNI.
- The Android CMake configuration pins an upstream Git commit so builds are reproducible.

## JE2BE Web

The browser application is a separate project and is not embedded in this Android app:
https://github.com/kbinani/je2be-web

## Resource-pack converter research

A separate Java-resource-pack to Bedrock-resource-pack converter exists here:
https://github.com/Seraphic-Studio/JE2BE-Resource-Pack-Converter

It is not currently bundled or integrated into this APK. The Android app currently scans for resource-pack references and reports them; it does not yet perform texture conversion. Review that project's MIT license, dependencies, mapping data, and Android/Python runtime compatibility before adding it.
